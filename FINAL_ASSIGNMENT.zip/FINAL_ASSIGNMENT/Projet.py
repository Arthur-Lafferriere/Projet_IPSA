# -*- coding: utf-8 -*-
"""
Created on Mon Apr 21 10:01:22 2025

@author: 33783
"""

import numpy as np
from functools import reduce
from itertools import permutations

#Definition of every task 
# Task = (time of execution , periode, number of the task)

List_task=[]

Task1=(2,10,1)
Task2=(3,10,2)
Task3=(2,20,3)
Task4=(2,20,4)
Task5=(2,40,5)
Task6=(2,40,6)
Task7=(3,80,7)

List_task.extend([Task1, Task2, Task3, Task4]) # List with all the task

#%% Hyperperiode 

periode=[task[1] for task in List_task]

def PPCM(a, b):
    """
    Parameters
    ----------
    a : int , the first periode.
    b : int , the second periode.

    Returns
    -------
    int, return the Least Common Multiple

    """
    return abs(a * b) // np.gcd(a, b)

hyperperiod = reduce(PPCM, periode)

#%% Generation of all instances

Task=[]
for task in List_task:
    execution_time,periode,id_task=task
    number_of_iteration=hyperperiod//periode
    for i in range(number_of_iteration):
        Task.append((id_task,execution_time,i*periode,(i+1)*periode))

#We create every task that we need in the time domaine, every component of the Task list is as follow:
# (id, execution time, initial time of the execution window, final time of the task execution)

#%% Generation of all  posible permutaion 

all_possible_case=permutations(Task)
# We use the permutations fonction from the library iterloops

#%% Check if the permutation is possible or not and calcul of the waiting time, identifie the best case also

def Time_check(permutaion,index=None):
    """
    Parameters
    ----------
    permutaion : permuation possibe
    index : id of the task that you can miss the dealine.

    Returns
    -------
    bool
        DESCRIPTION.
    waiting_time : TYPE
        DESCRIPTION.

    """
    time=0
    waiting_time=0
    for task in permutaion:
        if time<task[2]:
            time=task[2]
        if (time+task[1]>task[3]) and (task[0]!=index):
            return False,waiting_time
        waiting_time=waiting_time+time-task[2]
        time=time+task[1]
    return True,waiting_time


valide_permutation=[]
WT=[]
Best_case=0
Best_WT=hyperperiod

id_task_miss_dealine=None
for case in all_possible_case:
    Check,wainting_time=Time_check(case,id_task_miss_dealine)
    if Check==True:
        valide_permutation.append(case)
        WT.append(wainting_time)
        if Best_WT>wainting_time:
            Best_WT=wainting_time
            Best_case=case
# We look for every possible permutaion if it is possible or not and if it is , we add it in an list to save it
print("\n Optimal valid schedules in terms of waiting time")
for task in Best_case:
    print(f"  → Task {task[0]}")
print(f"  → Wainting time : {Best_WT} s")

